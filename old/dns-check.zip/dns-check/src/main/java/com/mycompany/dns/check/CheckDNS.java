package com.mycompany.dns.check;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.xbill.DNS.ResolverConfig;
import sun.net.dns.ResolverConfiguration;

public class CheckDNS {

    public static void main(String[] args) {
        String input = "";
        try {
            input = JOptionPane.showInputDialog(null, "Please, input host name:", "DNS check from " + InetAddress.getLocalHost().getHostAddress(), JOptionPane.QUESTION_MESSAGE);
        } catch (UnknownHostException ex) {
            Logger.getLogger(CheckDNS.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            JOptionPane.showMessageDialog(null, InetAddress.getByName(input), "dns answer:", JOptionPane.INFORMATION_MESSAGE);
        } catch (UnknownHostException ex) {
            Logger.getLogger(CheckDNS.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println(System.getProperty("sun.net.spi.nameservice.nameservers"));
        // 1 - method:
        String dnsServers[] = ResolverConfig.getCurrentConfig().servers();
        System.out.println(ResolverConfig.getCurrentConfig().servers()[0]);
        // 2 - method:
        List<String> nameservers = ResolverConfiguration.open().nameservers();
        nameservers.forEach(dns -> System.out.print(dns + " "));
    }

}
