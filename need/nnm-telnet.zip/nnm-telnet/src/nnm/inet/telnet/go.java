package nnm.inet.telnet;

public class go {

    public static void main(String[] args) {
        JTerm.telnet("10.73.250.43");
    }
    
}
