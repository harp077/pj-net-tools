package jpacketgenerator;

import java.util.logging.*;
import java.net.*;
import java.io.*;

public class TestPacket implements Serializable
{
    static final Object serialLock;
    static long currentSerialNumber;
    public long serialNumber;
    public long serializeTime;
    byte[] data;
    
    public TestPacket(final int pktLen) {
        this.serialNumber = 0L;
        this.serializeTime = 0L;
        this.initPacket(pktLen, false);
    }
    
    private TestPacket(final int pktLen, final boolean fTest) {
        this.serialNumber = 0L;
        this.serializeTime = 0L;
        this.initPacket(pktLen, true);
    }
    
    private void initPacket(final int pktLen, final boolean fTest) {
        synchronized (TestPacket.serialLock) {
            assert this.serializeTime == 0L;
            this.serialNumber = TestPacket.currentSerialNumber;
            if (!fTest) {
                ++TestPacket.currentSerialNumber;
            }
            this.data = new byte[pktLen - 127];
        }
    }
    
    public static int estimatePktLenght(final int dataSize) {
        final TestPacket test = new TestPacket(dataSize, true);
        return test.serialize().length;
    }
    
    public byte[] serialize() {
        final ByteArrayOutputStream fos = new ByteArrayOutputStream();
        try {
            final ObjectOutputStream oos = new ObjectOutputStream(fos);
            this.serializeTime = System.currentTimeMillis();
            oos.writeObject(this);
            oos.close();
        }
        catch (IOException ex) {
            Logger.getLogger(TestPacket.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fos.toByteArray();
    }
    
    public static TestPacket fromDatagramPacket(final DatagramPacket dpPkt) throws IOException {
        final ByteArrayInputStream bais = new ByteArrayInputStream(dpPkt.getData());
        final ObjectInputStream ois = new ObjectInputStream(bais);
        TestPacket testPacket = null;
        try {
            testPacket = (TestPacket)ois.readObject();
        }
        catch (ClassNotFoundException ex) {
            Logger.getAnonymousLogger().log(Level.SEVERE, null, ex);
        }
        ois.close();
        return testPacket;
    }
    
    static {
        serialLock = new Object();
        TestPacket.currentSerialNumber = 0L;
    }
}
