package jpacketgenerator;

import java.awt.event.*;
import javax.swing.event.*;
import java.util.logging.*;
import javax.swing.*;
import java.awt.*;
import java.net.*;
import java.util.*;

public class JPacketGeneratorGUI extends JFrame
{
    private packetGenerator pGenerator;
    private JComboBox CB_srcAddresses;
    private JSpinner S_packetSize_KB;
    private JSpinner S_streamSpeed;
    private JTextField TB_dtsAddress;
    private JTextField TB_dtsPort;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JButton startButton;
    private JButton stopButton;
    
    public JPacketGeneratorGUI() throws SocketException {
        this.initComponents();
        this.initSourceAddress();
    }
    
    private void initComponents() {
        this.CB_srcAddresses = new JComboBox();
        this.jLabel1 = new JLabel();
        this.jLabel2 = new JLabel();
        this.TB_dtsAddress = new JTextField();
        this.stopButton = new JButton();
        this.startButton = new JButton();
        this.S_packetSize_KB = new JSpinner();
        this.S_streamSpeed = new JSpinner();
        this.jLabel3 = new JLabel();
        this.jLabel4 = new JLabel();
        this.TB_dtsPort = new JTextField();
        this.setDefaultCloseOperation(3);
        this.CB_srcAddresses.setFont(new Font("Dialog", 1, 18));
        this.jLabel1.setText("Source Address");
        this.jLabel2.setText("Dest. Address - Port");
        this.TB_dtsAddress.setFont(new Font("Dialog", 0, 18));
        this.TB_dtsAddress.setHorizontalAlignment(2);
        this.TB_dtsAddress.setText("127.0.0.1");
        this.stopButton.setForeground(new Color(204, 0, 0));
        this.stopButton.setText("STOP");
        this.stopButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent evt) {
                JPacketGeneratorGUI.this.stopButtonMouseClicked(evt);
            }
        });
        this.stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent evt) {
                JPacketGeneratorGUI.this.stopButtonActionPerformed(evt);
            }
        });
        this.startButton.setForeground(new Color(0, 102, 51));
        this.startButton.setText("START");
        this.startButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent evt) {
                JPacketGeneratorGUI.this.startButtonMouseClicked(evt);
            }
        });
        this.startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent evt) {
                JPacketGeneratorGUI.this.startButtonActionPerformed(evt);
            }
        });
        this.S_packetSize_KB.setFont(new Font("Dialog", 1, 18));
        this.S_packetSize_KB.setModel(new SpinnerNumberModel(1324, 150, null, 50));
        this.S_packetSize_KB.setValue(1324);
        this.S_packetSize_KB.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent evt) {
                JPacketGeneratorGUI.this.S_packetSize_KBStateChanged(evt);
            }
        });
        this.S_streamSpeed.setFont(new Font("Dialog", 1, 18));
        this.S_streamSpeed.setModel(new SpinnerNumberModel(500, null, null, 50));
        this.S_streamSpeed.setValue(500);
        this.S_streamSpeed.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent evt) {
                JPacketGeneratorGUI.this.S_streamSpeedStateChanged(evt);
            }
        });
        this.jLabel3.setText("Packet Size (Bytes)");
        this.jLabel4.setText("Stream Speed (Kbps)");
        this.TB_dtsPort.setFont(new Font("Dialog", 0, 18));
        this.TB_dtsPort.setHorizontalAlignment(2);
        this.TB_dtsPort.setText("12345");
        final GroupLayout layout = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel1).addComponent(this.jLabel2).addComponent(this.jLabel3).addComponent(this.jLabel4)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(layout.createSequentialGroup().addGap(40, 40, 40).addComponent(this.CB_srcAddresses, 0, 243, 32767)).addGroup(layout.createSequentialGroup().addComponent(this.TB_dtsAddress, -2, 170, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.S_streamSpeed, GroupLayout.Alignment.TRAILING).addComponent(this.TB_dtsPort).addComponent(this.S_packetSize_KB, -2, 89, -2)))).addGap(54, 54, 54).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.startButton, GroupLayout.Alignment.TRAILING).addComponent(this.stopButton, GroupLayout.Alignment.TRAILING, -2, 77, -2)).addContainerGap()));
        layout.linkSize(0, this.startButton, this.stopButton);
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap(21, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.CB_srcAddresses, -2, -1, -2).addComponent(this.jLabel1)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.TB_dtsAddress, -2, -1, -2).addComponent(this.TB_dtsPort, -2, -1, -2).addComponent(this.jLabel2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.S_packetSize_KB, -2, -1, -2).addComponent(this.jLabel3)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.S_streamSpeed, -2, -1, -2).addComponent(this.jLabel4)).addContainerGap()).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.startButton, -2, 49, -2).addGap(6, 6, 6).addComponent(this.stopButton, -2, 49, -2).addGap(34, 34, 34)))));
        this.pack();
    }
    
    private void startButtonActionPerformed(final ActionEvent evt) {
    }
    
    private void startButtonMouseClicked(final MouseEvent evt) {
        try {
            final InetSocketAddress srcaddr = new InetSocketAddress(this.CB_srcAddresses.getSelectedItem().toString(), 0);
            final InetSocketAddress dstaddr = new InetSocketAddress(this.TB_dtsAddress.getText(), new Integer(this.TB_dtsPort.getText()));
            if (this.pGenerator != null) {
                this.pGenerator.close();
            }
            this.pGenerator = new packetGenerator(srcaddr, dstaddr, (int)this.S_packetSize_KB.getValue(), (int)this.S_streamSpeed.getValue() * 1000);
        }
        catch (SocketException ex) {
            Logger.getLogger(packetGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void stopButtonActionPerformed(final ActionEvent evt) {
    }
    
    private void stopButtonMouseClicked(final MouseEvent evt) {
        if (this.pGenerator != null) {
            this.pGenerator.close();
        }
    }
    
    private void S_packetSize_KBStateChanged(final ChangeEvent evt) {
        System.out.println("Packet Size changed. New Size:" + this.S_packetSize_KB.getValue());
        if (this.pGenerator != null) {
            this.pGenerator.setPacketSize((Integer)this.S_packetSize_KB.getValue());
        }
    }
    
    private void S_streamSpeedStateChanged(final ChangeEvent evt) {
        System.out.println("Stream Speed changed. New Speed:" + (int)this.S_streamSpeed.getValue() * 1000);
        if (this.pGenerator != null) {
            this.pGenerator.setStreamSpeed((int)this.S_streamSpeed.getValue() * 1000);
        }
    }
    
    public static void main(final String[] args) {
        if (args.length == 0) {
            try {
                for (final UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            }
            catch (ClassNotFoundException ex) {
                Logger.getLogger(JPacketGeneratorGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (InstantiationException ex2) {
                Logger.getLogger(JPacketGeneratorGUI.class.getName()).log(Level.SEVERE, null, ex2);
            }
            catch (IllegalAccessException ex3) {
                Logger.getLogger(JPacketGeneratorGUI.class.getName()).log(Level.SEVERE, null, ex3);
            }
            catch (UnsupportedLookAndFeelException ex4) {
                Logger.getLogger(JPacketGeneratorGUI.class.getName()).log(Level.SEVERE, null, ex4);
            }
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        new JPacketGeneratorGUI().setVisible(true);
                    }
                    catch (SocketException ex) {
                        Logger.getLogger(JPacketGeneratorGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        }
        else {
            try {
                if (args.length < 3) {
                    System.out.println(" srcAddress srcPort dstAddress dstPort bitRate_bps");
                }
                else {
                    final InetSocketAddress srcAddress = new InetSocketAddress(args[0], Integer.parseInt(args[1]));
                    final InetSocketAddress dstAddress = new InetSocketAddress(args[2], Integer.parseInt(args[3]));
                    final int birtate = Integer.parseInt(args[4]);
                    final packetGenerator packetGenerator = new packetGenerator(srcAddress, dstAddress, 1324, birtate);
                }
            }
            catch (SocketException ex5) {
                Logger.getLogger(JPacketGeneratorGUI.class.getName()).log(Level.SEVERE, null, ex5);
            }
        }
    }
    
    private void initSourceAddress() throws SocketException {
        final Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
        for (final NetworkInterface netint : Collections.list(nets)) {
            final Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
            for (final InetAddress addr : Collections.list(inetAddresses)) {
                if (addr instanceof Inet4Address) {
                    this.CB_srcAddresses.addItem(addr.getHostAddress());
                }
            }
        }
        this.CB_srcAddresses.setSelectedItem("127.0.0.1");
    }
}
