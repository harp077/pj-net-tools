package jpacketgenerator;

import java.util.concurrent.*;
import java.net.*;
import java.util.logging.*;

public class packetGenerator
{
    private ScheduledExecutorService executor;
    private DatagramSocket sock;
    private final Object packetLock;
    private InetSocketAddress dstAddress;
    private boolean fClosing;
    private int speed_bps;
    private Integer requiredPktSize;
    
    public packetGenerator(final InetSocketAddress scrAddress, final InetSocketAddress destAddress, final int packetSize, final int speed_bps) throws SocketException {
        this.packetLock = new Object();
        this.fClosing = false;
        this.sock = new DatagramSocket(scrAddress);
        this.dstAddress = destAddress;
        this.requiredPktSize = packetSize;
        this.speed_bps = speed_bps;
        this.restartStream();
        System.out.println("Packet generator: streaming!");
    }
    
    public synchronized void close() {
        this.stopExecutor();
        this.sock.close();
        System.out.println("Packet generator: stopped!");
    }
    
    public final void restartStream() {
        synchronized (this.packetLock) {
            this.stopExecutor();
            this.executor = Executors.newSingleThreadScheduledExecutor();
            final long timePeriod = this.evaluateTimePeriod(this.speed_bps, this.requiredPktSize);
            if (timePeriod > 0L) {
                System.out.println("Period Time:" + (Object)(timePeriod / 1000000.0) + " msec");
                this.executor.scheduleAtFixedRate(new PacketSender(), 0L, timePeriod, TimeUnit.NANOSECONDS);
            }
            else {
                System.out.println("NOT VALID Period Time:" + (Object)(timePeriod / 1000.0) + " msec");
            }
        }
    }
    
    private void stopExecutor() {
        if (this.executor != null) {
            this.executor.shutdown();
        }
    }
    
    private synchronized long evaluateTimePeriod(final int speed_bps, final int packetSize) {
        final long timePeriod = (long)(1.0 / (speed_bps / (double)(packetSize * 8)) * 1.0E9);
        return timePeriod;
    }
    
    public synchronized void setPacketSize(final Integer iPktSize) {
        this.requiredPktSize = iPktSize;
        this.restartStream();
    }
    
    public synchronized void setStreamSpeed(final int speed) {
        this.speed_bps = speed;
        this.restartStream();
    }
    
    private DatagramPacket createNewPacket() {
        final TestPacket testPkt = new TestPacket((int)this.requiredPktSize);
        final byte[] data = testPkt.serialize();
        return new DatagramPacket(data, data.length, this.dstAddress.getAddress(), this.dstAddress.getPort());
    }
    
    class PacketSender implements Runnable
    {
        @Override
        public void run() {
            try {
                synchronized (packetGenerator.this.packetLock) {
                    final DatagramPacket pkt = packetGenerator.this.createNewPacket();
                    packetGenerator.this.sock.send(pkt);
                }
            }
            catch (Exception ex) {
                if (!packetGenerator.this.fClosing) {
                    Logger.getLogger(packetGenerator.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
