package os.info;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.file.FileStore;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import org.xbill.DNS.ResolverConfig;
import oshi.SystemInfo;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.software.os.OperatingSystem;
//import java.lang.management.OperatingSystemMXBean;
//import com.sun.management.OperatingSystemMXBean;

public class OsInfo {

    private static final com.sun.management.OperatingSystemMXBean sunOS = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
    private static final java.lang.management.OperatingSystemMXBean lanOS = ManagementFactory.getOperatingSystemMXBean();
    private static final SystemInfo si = new SystemInfo();
    private static final HardwareAbstractionLayer ha = si.getHardware();
    private static final OperatingSystem os = si.getOperatingSystem();  
    private static String info;

    public static void main(String[] args) {
        //InetAddress.getLocalHost()
        //System.getProperties();
        //System.getenv();
        //System.out.println("os.name: " + sunOS.getName());
        //System.out.println("os.arch: " + sunOS.getArch());
        //System.out.println("os.version: " + sunOS.getVersion());
        System.out.println("_______Memory:\nTotalPhysicalMemory: " + sunOS.getTotalPhysicalMemorySize() / 1000000);
        System.out.println("FreePhysicalMemory: " + sunOS.getFreePhysicalMemorySize() / 1000000);
        //System.out.println("FreeSwapSpace: " + os.getFreeSwapSpaceSize() / 1000000);
        //System.out.println(os.getProcessCpuLoad());
        //System.out.println("availableProcessors: " + sunOS.getAvailableProcessors());
        // LOAD NOT WORK IN WINDOWS !!!
        //System.out.println("SystemCpuLoad: " + sunOS.getSystemCpuLoad());
        //System.out.println("SystemLoadAverage: " + sunOS.getSystemLoadAverage());
        //System.out.println("Average OS load by 1 CPU: " + sunOS.getSystemLoadAverage() / sunOS.getAvailableProcessors());
        //System.out.println("lanOS.getSystemLoadAverage(): " + lanOS.getSystemLoadAverage());
        ///
        System.out.println("\n_______FS:");
        //File[] roots = File.listRoots();
        for (File root : File.listRoots()) {
            System.out.println("File system root: " + root.getAbsolutePath());
            System.out.println("Total space Mb: " + root.getTotalSpace() / 1000000);
            //System.out.println("Free space Mb: " + root.getFreeSpace() / 1000000);
            System.out.println("Usable space Mb: " + root.getUsableSpace() / 1000000);
        }
        ///
        //NumberFormat nf = NumberFormat.getNumberInstance();
        /*for (Path root : FileSystems.getDefault().getRootDirectories()) {
            System.out.println("\nroot FS = " + root);
            try {
            FileStore store = Files.getFileStore(root);
            System.out.println("TotalSpace Mb = " + store.getTotalSpace()/1000000);
            System.out.println("UsableSpace Mb = " + store.getUsableSpace()/1000000);
            } catch (IOException e) {
            System.out.println("error querying space: " + e.toString());
            }
        }*/
        System.out.println("\n_______OSHI:");
        //System.out.println(ha.getComputerSystem().getBaseboard().getModel());
        //System.out.println(ha.getComputerSystem().getBaseboard().getManufacturer());
        //System.out.println(ha.getComputerSystem().getBaseboard().getVersion());
        //System.out.println(ha.getComputerSystem().getManufacturer());
        System.out.println(ha.getComputerSystem().getModel());
        System.out.println(ha.getProcessor().getName());
        //System.out.println(ha.getComputerSystem().getSerialNumber());
        System.out.println(ha.getNetworkIFs()[0].getDisplayName());
        System.out.println((ha.getNetworkIFs()[0].getBytesRecv()+0.0)/(1024*1024));
        System.out.println((ha.getNetworkIFs()[0].getBytesSent()+0.0)/(1024*1024));
        //Arrays.asList(ha.getNetworkIFs()).stream().forEach(x->System.out.println(x.getName()));
        //System.out.println(ha.getDiskStores()[0].getName());
        //System.out.println(ha.getDisplays()[0].toString());
        //System.out.println(ha.getMemory().getTotal()/ 1000000);
        //System.out.println(ha.getMemory().getAvailable()/ 1000000);
        //System.out.println(ha.getPowerSources().toString());
        //System.out.println(ha.getProcessor().getFamily());
        //System.out.println(ha.getProcessor().getIdentifier());
        //System.out.println(ha.getProcessor().getModel());
        //System.out.println(ha.getProcessor().getSystemCpuLoad()*4);
        //System.out.println(ha.getProcessor().getSystemLoadAverage());
        System.out.println("uptime, min = "+ha.getProcessor().getSystemUptime()/60);
        //System.out.println(ha.getProcessor().isCpu64bit());
        //
        //System.out.println(os.getFamily());
        //System.out.println(os.getFileSystem().getFileStores()[0].getName());
        //System.out.println(os.getManufacturer());
        //System.out.println(os.getNetworkParams().getDnsServers()[0]);
        //System.out.println(os.getNetworkParams().getHostName());
        //System.out.println(os.getThreadCount());
        //System.out.println(os.getVersion());
        System.out.println("\n_______System.get*:");
        //System.out.println(System.getProperties().getProperty("sun.os.patch.level"));
        System.out.println(System.getProperties().getProperty("os.arch"));
        System.out.println(System.getProperties().getProperty("os.name"));
        System.out.println(System.getProperties().getProperty("os.version"));
        //System.out.println(System.getProperties().getProperty("sun.arch.data.model"));
        //
        /*System.out.println(System.getenv().get("PROCESSOR_LEVEL"));
        System.out.println(System.getenv().get("PROCESSOR_ARCHITECTURE"));
        System.out.println(System.getenv().get("OS"));
        System.out.println(System.getenv().get("PROCESSOR_REVISION"));
        System.out.println(System.getenv().get("PROCESSOR_IDENTIFIER"));
        System.out.println(System.getenv().get("NUMBER_OF_PROCESSORS"));
        System.out.println(System.getenv().get("HOMEDRIVE"));
        System.out.println(System.getenv().get("COMPUTERNAME"));*/
        //
        System.out.println("_______CPU:\nCPU kernels: " + Runtime.getRuntime().availableProcessors());
        info = "\nLocal Network:\n-------------\nsystem local interfaces:\n";
        Enumeration enm=null;
        try {
            enm = NetworkInterface.getNetworkInterfaces();
        } catch (SocketException ex) {
            //Logger.getLogger(CdiSysInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<NetworkInterface> listNI = Collections.list(enm);
        for (NetworkInterface ni: listNI) {
            info = info + ni.getName() +"\n";
            info = info + ni.getInetAddresses() +"\n";
        }
        /*while (enm.hasMoreElements()) {
            NetworkInterface n = (NetworkInterface) enm.nextElement();
            Enumeration ee = n.getInetAddresses();
            while (ee.hasMoreElements()) {
                InetAddress i = (InetAddress) ee.nextElement();
                info = info + i.getHostAddress() + "\n";
                //System.out.println(i.getHostAddress());
            }
        }*/
        info = info + "Local DNS-servers:\n";
        Arrays.asList(ResolverConfig.getCurrentConfig().servers())
                .stream()
                .forEach(x->info=info+x+"\n");
        info = info + "\n";
        System.out.println(info);
    }

}
