/*
 * Visit url for update: http://sourceforge.net/projects/jvtelnet
 * 
 * JvTelnet was developed by http://sourceforge.net/users/bpetrovi
 * The sources was donated to sourceforge.net under the terms 
 * of GNU Lesser General Public License (LGPL). Redistribution of any 
 * part of JvTelnet or any derivative works must include this notice.
 */
package cz.dhl.term;

/** 
 * @version 0.23 06/09/2003
 * @author Bea Petrovicova   
 */
public interface SerialEventListener {
    public void serialEvent();
}
