java -jar jvtelnet.jar [options] telnet.server.com

 --sockport     -s  socket port is next argument

 Serial Printer (Requires JavaCOMM)
 --answerback   -a  answerback message is next argument
 --baudrate     -b  baudrate is next argument
                       example: 9600
 --commport     -c  commport is next argument
                       windows example: COM1
                       linux example: /dev/term/a
 --flowcontrol  -k  flowcontrol is next argument
                       none  no flow control
                       hw    RTS/CTS flow control.
                       sw    XON/XOFF flow control.

 Other
 --loopconnect  -l  reconnect in loop
 --debugon      -d  debug mode on
 --unicodeoff   -e  do not use extended unicode characters
 --fontname     -f  fontname is next argument
 --config       -i  config file is next argument
 --doublebuffer -r  turn off screen doublebuffer
                       (might help on graphics terminals)
 --help         -h  this help screen
