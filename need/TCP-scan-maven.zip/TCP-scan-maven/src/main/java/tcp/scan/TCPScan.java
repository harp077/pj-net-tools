package tcp.scan;

import java.io.IOException;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TCPScan {
    
    private static final String tcp_ports="21-22-23-25-49-53-80-88-110-113-135-139-143-179-220-443-445-465-587-";
    private static final String udp_ports="53-69-123-161-162-514-";
    
    public static Double scanTCP(String ip, int port) {
        int timeout=222;
        try {
            SocketAddress sockaddr = new InetSocketAddress(ip,port);
            Socket sc = new Socket();
            sc.connect(sockaddr, timeout);
            sc.close();
            System.out.println("open = "+port);
            return 0.0+port;
        } catch (UnknownHostException e) {
            //System.out.println("UnknownHostException");
        } catch (ConnectException ex) {
            //System.out.println("ConnectException");
        } catch (SocketTimeoutException ex) {
            //System.out.println("SocketTimeoutException");
        } catch (IOException ex) {
            //System.out.println("IOException");
        }
        return 0.0;
    }

    public static void main(String[] args) {
        List<Integer> tcpPortList=new ArrayList<>();
        Map<Integer,Double> tcpPortMap=new HashMap<>();
        for (String j: tcp_ports.split("-")) {
            tcpPortList.add(Integer.parseInt(j));
        }
        tcpPortList.parallelStream()
                .forEach(x->tcpPortMap.put(x, scanTCP("demo.snmplabs.com", x)));
        System.out.println(tcpPortMap.entrySet()
                .parallelStream()
                //.sorted((p1,p2)->Integer.compare(p1.getKey(), p2.getKey()))
                .collect(Collectors.toMap(p -> p.getKey(), p -> p.getValue())));
    }

}
